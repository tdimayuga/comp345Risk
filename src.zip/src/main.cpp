//============================================================================
// Name        : Assignment1COMP345GameDriver.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "country.h"
#include "player.h"
#include "gamedriver.h"

#include <iostream>

using namespace std;
using namespace risk;

int main() {
		GameDriver driver;

		int defaultArmy = 10;

		Player player1(defaultArmy, "Sean");
		Country canada(&player1, defaultArmy, "Canada");
		player1.setCountry(&canada);

		Player player2(defaultArmy, "Trisha");
		Country usa(&player2, defaultArmy, "USA");
		player2.setCountry(&usa);

		driver.addPlayers(&player1);
		driver.addPlayers(&player2);

		std::vector<Player*> players = driver.getPlayers();

		cout << "Display of the values." << endl;

		for(int i = 0; i < players.size(); i++) {
			cout << "Player's name: "<< players[i]->getName() << endl;
			cout << "Player's country: " << players[i]->getCountries()[0]->getName() << endl;
			cout << "Player's army: " << players[i]->getArmies() << endl;
			cout << "To be sure it's the right owner: " << players[i]->getCountries()[0]->getOwner()->getName() << endl;
			cout << "=========" << endl;
		}

		return 0;
}
